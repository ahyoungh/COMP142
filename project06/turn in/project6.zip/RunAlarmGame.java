package project6;
/* Ahyoung Hwang I have neither given nor received unauthorized aid on this program. */

public class RunAlarmGame {
    public static void main(String[] args)
    {
        AlarmGame theGame = new AlarmGame();
        theGame.runGame();
    }

}
