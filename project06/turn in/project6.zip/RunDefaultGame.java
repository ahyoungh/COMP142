package project6;
/* Ahyoung Hwang - I have neither given nor received unauthorized aid on this program. */

public class RunDefaultGame {
    public static void main(String[] args)
    {
        Game theGame = new Game(600, 400);
        theGame.runGame();
    }
}
